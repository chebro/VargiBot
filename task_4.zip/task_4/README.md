# Task 4

#### Picking and Sorting packages using UR5 (UR5#1 & UR5#2) in Gazebo.

# Video

Check out the video on youtube:

[![](https://i.imgur.com/qDZyMqa.png)](https://youtu.be/GypkJuPeiIA "eYRC_VB_task_4")
